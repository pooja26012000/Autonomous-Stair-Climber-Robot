READ ME 

The main Product Build Proposal is the PDF file of the
Proof of Concept for our Stair Climbing robot. 

As part of the proposal, we have created flowcharts, 
a simulation video and a video about the user interface. 

All these files are attached in the PDF file and can be accessed/seen. 
In case the videos don't play or the flowcharts aren't visible, we have also 
attached them in this zip file. 